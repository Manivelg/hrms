
// Sidemenu

 // json Data

 let sidemenu_data = [
  {
      "id" : 1,
      "image": "home.svg",
      "header": "Home",
  },
  {
      "id" : 2,
      "image": "dashboard.svg",
      "header": "Dashboard",
  },
  {
      "id" : 3,
      "image": "attendance.svg",
      "header": "Attendance",
  },
  {
      "id" : 4,
      "image": "leave.svg",
      "header": "Leaves",
  },
  {
      "id" : 5,
      "image": "emp_dir.svg",
      "header": "Employee Directory",
  },
  {
      "id" : 6,
      "image": "documents.svg",
      "header": "Documents",
  },
  {
      "id" : 7,
      "image": "payroll.svg",
      "header": "Payroll",
  },
  {
      "id" : 8,
      "image": "project.svg",
      "header": "Projects",
  },
  {
      "id" : 9,
      "image": "performance.svg",
      "header": "Performance",
  },
  {
      "id" : 10,
      "image": "asset.svg",
      "header": "Assets",
  },
  {
      "id" : 11,
      "image": "vendor.svg",
      "header": "Vendor Management",
  }

];
  // json Data

  let menu_data = sidemenu_data.map(function(e) 
  {
      return `
              <div class='side_one' id=${e.header}>
                  <embed src='asset/sidemenu/${e.image}' class='sidemenu_img' alt=${e.header} data-title='welcome'/>
                  <p class='side_header'>${e.header}</p>
              </div> `;
  });

  document.getElementById('side_nav').innerHTML = menu_data.join('');


//side menu

//sidemenu click function
$(".side0").click(function(){window.location.href='main_two.html';});


//No Data
