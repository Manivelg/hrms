 // json Data

 let data = [
    {
        "id" : 1,
        "image": "attendance.svg",
        "header": "Attendance",
    },
    {
        "id" : 2,
        "image": "leaves.svg",
        "header": "Leaves",
    },
    {
        "id" : 3,
        "image": "directory.svg",
        "header": "Directory",
    },
    {
        "id" : 4,
        "image": "documents.svg",
        "header": "Documents",
    },
    {
        "id" : 5,
        "image": "payroll.svg",
        "header": "Payroll",
    },
    {
        "id" : 6,
        "image": "projects.svg",
        "header": "Projects",
    },
    {
        "id" : 7,
        "image": "performance.svg",
        "header": "Performance",
    },
    {
        "id" : 8,
        "image": "assets.svg",
        "header": "Assets",
    },
    {
        "id" : 9,
        "image": "careers.svg",
        "header": "Careers",
    },
    {
        "id" : 10,
        "image": "exit_process.svg",
        "header": "Exit Process",
    },
    {
        "id" : 11,
        "image": "approvals.svg",
        "header": "Approvals",
    },
    {
        "id" : 12,
        "image": "other_request.svg",
        "header": "Other Requests",
    }

];
    // json Data

    let newData = data.map(function(e) 
    {
        return `
                <div class='first' id=${e.header}>
                    <embed src='asset/dashboard/${e.image}' class='head_img' alt='Sample image' data-title='welcome'/>
                    <p class='first_header'>${e.header}</p>
                </div> `;
    });

    document.getElementById('dashboard').innerHTML = newData.join('');
