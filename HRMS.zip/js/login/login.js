function submit() {
window.location.href = '../main.html';
}